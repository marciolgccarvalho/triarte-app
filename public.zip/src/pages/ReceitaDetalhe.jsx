import React from "react";
import ParabensModal from "../components/ParabensModal";
import { IMAGES } from "../assets/images";
import "../styles/components/receita-detalhe.css";

export default function ReceitaDetalhe({
  receita,
  marcarVideo,
  percentual,
  progresso,
  voltar,
  irPara
}) {
  const [mostrarParabens, setMostrarParabens] = React.useState(false);
  const prevPercentual = React.useRef(0);

  if (!receita) {
    return <div className="page">Nenhuma receita selecionada</div>;
  }

  const vistos = progresso[receita.id]?.vistos || [];
  const total = receita.videos.length;
  const atual = percentual(receita);

  // próxima etapa
  const proximaIndex = receita.videos.findIndex(
    (_, i) => !vistos.includes(i)
  );

  const proximaEtapa =
    proximaIndex >= 0 ? receita.videos[proximaIndex] : null;

  React.useEffect(() => {
    if (prevPercentual.current < 100 && atual === 100) {
      setMostrarParabens(true);
    }
    prevPercentual.current = atual;
  }, [progresso]);

  return (
    <div className="page">

      {/* HEADER */}
      <button onClick={voltar} className="btn-voltar">
        <img
          src={IMAGES.icons.anterior.active}
          alt="Voltar"
        />
      </button>

      {/* IMAGEM */}
      <div className="receita-hero-wrapper">
        <img
          src={receita.imagem}
          alt={receita.nome}
          className="receita-hero"
        />

        <button
          className={`receita-fav ${favoritos?.includes(receita.id) ? "ativo" : ""}`}
          onClick={() => toggleFavorito(receita.id)}
        >
          <img
            src={IMAGES.icons.favoritos.active}
            alt="Favoritar"
          />
        </button>
      </div>

      {/* TÍTULO */}
      <h2 className="receita-titulo">{receita.nome}</h2>

      <p className="receita-sub">
        {receita.descricao}
      </p>

      {/* AÇÕES */}
      <div className="acoes">
        <button
          className="btn btn-primary btn-full"
          onClick={() =>
            window.open(
              `https://www.youtube.com/watch?v=${receita.videos[0].youtubeId}`,
              "_blank"
            )
          }
        >
          ▶ Assistir no YouTube
        </button>

        <button
          className="btn btn-secondary btn-full"
          onClick={() => irPara("materiais")}
        >
          Materiais da Receita
        </button>
      </div>

      {/* PROGRESSO */}
      <div className="card progresso-card">
        <div className="flex-between">
          <strong>Seu progresso</strong>
          <span>{vistos.length} de {total}</span>
        </div>

        <div className="progress-bar mt-sm">
          <div
            className="progress-fill"
            style={{ width: `${atual}%` }}
          />
        </div>

        <div className="progress-text">{atual}%</div>
      </div>

      {/* CONTINUAR */}
      {proximaEtapa && (
        <div className="card continuar-card">
          <span className="small">Continue de onde parou</span>

          <strong>
            Parte {proximaIndex + 1} – {proximaEtapa.titulo}
          </strong>

          <button
            className="btn-continuar"
            onClick={() =>
              window.open(
                `https://www.youtube.com/watch?v=${proximaEtapa.youtubeId}`,
                "_blank"
              )
            }
          >
            Continuar →
          </button>
        </div>
      )}

      {/* ETAPAS */}
      <div className="etapas">
        <h3>Etapas da receita</h3>

        {receita.videos.map((video, index) => {
          const visto = vistos.includes(index);

          return (
            <div
              key={index}
              className={`etapa-item ${visto ? "done" : ""}`}
            >
              <div className="etapa-left">
                <span className="etapa-icon">
                  {visto ? "✔" : index === proximaIndex ? "▶" : "•"}
                </span>

                <span>
                  Parte {index + 1}
                </span>
              </div>

              <button
                className="btn-etapa"
                onClick={() =>
                  window.open(
                    `https://www.youtube.com/watch?v=${video.youtubeId}`,
                    "_blank"
                  )
                }
              >
                {visto ? "Concluído" : "Assistir"}
              </button>
            </div>
          );
        })}
      </div>

      <ParabensModal
        aberto={mostrarParabens}
        fechar={() => setMostrarParabens(false)}
        receita={receita}
      />
    </div>
  );
}